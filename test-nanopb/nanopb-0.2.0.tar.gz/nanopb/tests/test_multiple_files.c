/*
 * Tests if still compile if typedefs are redfefined in STATIC_ASSERTS when
 * proto file includes another poto file
 */

#include <stdio.h>
#include <pb_encode.h>
#include "callbacks2.pb.h"

int main()
{
	return 0;
}
